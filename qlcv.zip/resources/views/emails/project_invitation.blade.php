<h1>Xin chào!</h1>
<p>Bạn được mời tham gia dự án.</p>
<p>
    Nhấn vào link để chấp nhận lời mời:
    <a href="{{ url('/accept-invite/' . $invitation->token) }}">Chấp nhận</a>
</p>