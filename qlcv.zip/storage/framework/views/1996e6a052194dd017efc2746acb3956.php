<h1>Xin chào!</h1>
<p>Bạn được mời tham gia dự án.</p>
<p>
    Nhấn vào link để chấp nhận lời mời:
    <a href="<?php echo e(url('/accept-invite/' . $invitation->token)); ?>">Chấp nhận</a>
</p><?php /**PATH C:\xampp\htdocs\qlcv\resources\views/emails/project_invitation.blade.php ENDPATH**/ ?>